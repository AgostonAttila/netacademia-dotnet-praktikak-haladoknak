﻿using Common;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RepositoryA
{
    [Export(typeof(IRepository))]
    public class Repository : IRepository
    {
        public IEnumerable<string> GetStrings()
        {
            return new string[] { "A", "alma", "barack", "citrom" };
        }
    }
}
