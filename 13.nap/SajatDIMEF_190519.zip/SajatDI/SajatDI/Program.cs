﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition.Hosting;
using System.ComponentModel.Composition;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.Composition.Registration;
using Common;

namespace SajatDI
{
    class Program
    {
        static void Main(string[] args)
        {
            //IRepository repos;
            //RepositoryGyar gyar = new RepositoryGyar();
            //repos = gyar.AdjRepositoryt();

            //var munkas = new Munkas(repos);

            //var container = new Container();
            //container.Register<Munkas, Munkas>();
            //container.Register<IRepository, MasikRepository>();
            //container.ExportInterfaces(Assembly.GetExecutingAssembly());

            var builder = new RegistrationBuilder();
            builder.ForTypesDerivedFrom<IRepository>().Export<IRepository>();
            builder.ForType<Munkas>().Export();

            var aggrCatalog = new AggregateCatalog();
            var catalog = new DirectoryCatalog("plugins", builder);

            aggrCatalog.Catalogs.Add(catalog);
            aggrCatalog.Catalogs.Add(new AssemblyCatalog(typeof(Munkas).Assembly, builder));

            var container = new CompositionContainer(aggrCatalog);
            
            
            var munkas = container.GetExport<Munkas>().Value;
            //container.ComposeParts(munkas);

            munkas.Dolgozz();
        }
    }
    

    //public class Container
    //{
    //    private Dictionary<Type, Type> registry = new Dictionary<Type,Type>();

    //    public T Get<T>()
    //    {
    //        //return default(T);
    //        return (T)Get(typeof(T));
    //    }

    //    private object Get(Type type1)
    //    {
    //        Type keszTipus;
    //        if(registry.ContainsKey(type1))
    //        {
    //            keszTipus = registry[type1];
    //        }
    //        else
    //        {
    //            keszTipus = type1;
    //        }

    //        //mi van ha nincs konstruktor parameter
    //        var konst = keszTipus.GetConstructors().First();
    //        var parameters = konst.GetParameters();

    //        if (parameters.Count() == 0)
    //            return Activator.CreateInstance(keszTipus);

    //        List<object> constructorParameters = new List<object>();

    //        //és mi van ha van konstruktor parameter
    //        foreach (var param in parameters)
    //        {
    //            constructorParameters.Add(Get(param.ParameterType));
    //        }

    //        return konst.Invoke(constructorParameters.ToArray());
    //    }

    //    public void Register<T1, T2>()
    //    {
    //        registry.Add(typeof(T1), typeof(T2));
    //    }


    //    public void ExportInterfaces(Assembly assembly)
    //    {
    //        var alltypes = assembly.GetExportedTypes();
    //        foreach (var tipus in alltypes)
    //        {
    //            var interfaces = tipus.GetInterfaces();
    //            foreach (var intf in interfaces)
    //            {
    //                registry.Add(intf, tipus);
    //            }
    //        }
    //    }
    
    //}

    //public class RepositoryGyar
    //{
    //    static Random r = new Random();

    //    public IRepository AdjRepositoryt()
    //    {
    //        var a = r.Next(2);
    //        if (a == 0)
    //            return new Repository();

    //        return new MasikRepository();
    //    }
    //}

}
