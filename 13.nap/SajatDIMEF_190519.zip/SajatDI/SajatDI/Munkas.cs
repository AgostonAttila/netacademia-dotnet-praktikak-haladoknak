﻿using Common;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SajatDI
{
    public class Munkas
    {
        IEnumerable<IRepository> repos;

        public Munkas(IEnumerable<IRepository> repos)
        {
            this.repos = repos;
        }

        //public Munkas(IRepository repos)
        //{
        //    this.repos = repos;
        //}

        public void Dolgozz()
        {
            foreach (var item in repos)
            {
                Console.WriteLine(string.Join(", ", item.GetStrings()));

            }
        }
    }
}
