﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.Caching;

namespace Tocsi.Web.Mvc.Resources
{
    public class ResourceEntry
    {
        [Key]
        [Column(Order=0)]
        [MaxLength(50)]
        public string ResourceClass { get; set; }

        [Key]
        [Column(Order = 1)]
        [MaxLength(50)]
        public string ResourceKey { get; set; }

        [Key]
        [Column(Order = 2)]
        [MaxLength(500)]
        public string Culture { get; set; }

        public string ResourceString { get; set; }

    }

    public class ResourceContext:DbContext
    {
        public DbSet<ResourceEntry> Entries { get; set; }

        string schema;
        string table;

        public ResourceContext(string connectionStringName, string schema, string table):base(connectionStringName)
        {
            this.schema = schema;
            this.table = table;
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ResourceEntry>().ToTable(table, schema);
        }
    }

    public interface IResourceRepository
    {
        void InvalidateResourceCache(string resourceTable = null, string resourceClass = null);
        string GetResourceString(string resourceTable, string resourceClass, string resourceKey, string defaultValue = null, string comment = null, bool isHtml = false);
        void UpdateResourceString(string resourceTable, string resourceClass, string resourceKey, string resourceValue);
    }



    public class DatabaseResourceRepository : IResourceRepository
    {
        /// <summary>
        /// arg1: resourceTable
        /// arg2: resourceClass
        /// </summary>
        public static Func<string, string, string> ResourcesConnectionStringNameFunction;

        /// <summary>
        /// arg1: resourceTable
        /// arg2: resourceClass
        /// </summary>
        public static Func<string, string, int> CacheTimeoutFunction;

        public StringDictionary ReadResourceClass(string resourceTable, string resourceClass, string culture)
        {
            var dictionary = new StringDictionary();

            string connectionStringName;
            string schema;
            GetConnectionProperties(resourceClass, ref resourceTable, out connectionStringName, out schema);

            using (ResourceContext ctx = new ResourceContext(connectionStringName,schema, resourceTable))
            {
                var entries = from r in ctx.Entries
                              where r.ResourceClass == resourceClass
                              && r.Culture == culture
                              select r;

                foreach (var entry in entries)
                {
                    dictionary[entry.ResourceKey] = entry.ResourceString;
                }
            }

            return dictionary;
        }

        private static void GetConnectionProperties(string resourceClass, ref string resourceTable,  out string connectionStringName, out string schema)
        {
            connectionStringName = null;
            if (ResourcesConnectionStringNameFunction != null)
                connectionStringName = ResourcesConnectionStringNameFunction(resourceTable, resourceClass);

            if (string.IsNullOrWhiteSpace(connectionStringName))
                connectionStringName = System.IO.Path.GetFileNameWithoutExtension(resourceTable);


            schema = null;
            var resourceTableParts = resourceTable.Split(new char[] { '.' }, 2);
            if (resourceTableParts.Length == 2)
            {
                schema = resourceTableParts[0];
                resourceTable = resourceTableParts[1];
            }
        }

        public void Write(string resourceTable, string resourceClass, string resourceKey, string resourceValue, string culture)
        {
            string connectionStringName;
            string schema;
            GetConnectionProperties(resourceClass, ref resourceTable, out connectionStringName, out schema);

            using (ResourceContext ctx = new ResourceContext(connectionStringName, schema, resourceTable))
            {
                var existingEntry = ctx.Entries.Find(resourceClass, resourceKey, culture);
                if (existingEntry == null)
                {
                    var defaultValue = new ResourceEntry { ResourceClass = resourceClass, ResourceKey = resourceKey, Culture = culture, ResourceString = resourceValue };
                    ctx.Entries.Add(defaultValue);
                }
                else
                {
                    existingEntry.ResourceString = resourceValue;
                }
                ctx.SaveChanges();
            }

        }


        /// <summary>
        /// (cult, table, class)
        /// </summary>
        private const string CacheKeyTemplate = "{0}.{1}.{2}";

        /// <summary>
        /// (cult, table)
        /// </summary>
        private const string TableLevelCacheKeyTemplate = "{0}.{1}.AllClasses";

        /// <summary>
        /// (cult)
        /// </summary>
        private const string CultureLevelCacheKeyTemplate = "{0}.AllTables.AllClasses";

        /// <summary>
        /// Ha a környezetből úgy ítéli meg, akkor, segíti a szerkesztést
        /// </summary>
        private bool ResourceEditorMode
        {
            get
            {
                var ctx = HttpContext.Current;
                return ctx != null &&
                    (ctx.Request.QueryString["res"] == "1"
                    || (string)ctx.Items["res"] == "1"
                    || (string)ctx.Session["res"] == "1");
            }
        }


        /// <summary>
        /// Ez csak egy alapértelmezett implementáció, ide jöhet a domain név
        /// vagy bármi ami alapján különböző resource-okat szeretnénk visszaadni
        /// <para>
        /// egyben ez szolgál kontroll cache elemnént az összes ehhez a nyelvhez/változathoz tartozó resource kidobásához
        /// </para>
        /// </summary>
        public string CultureDiscriminator
        {
            get
            {
                string disc;
                disc = Thread.CurrentThread.CurrentUICulture.ToString();
                return disc;
            }
        }

        /// <summary>
        /// Kidobja a memóriából az adott ResourceClass ba tartozó resource értékeket,
        /// amiket a megadott ResourceTable-ből olvasott be.
        /// <para>
        /// Ezt hívja a generált statikus resource osztály Reset() metódusa
        /// </para>
        /// </summary>
        /// <param name="resourceTable">
        /// A tábla neve sémával együtt.
        /// </param>
        /// <param name="resourceClass"> A tábla ResourceClass oszlopában keresendő érték.
        /// <para>
        /// A T4 template ezzel a névvel készítette el az elérő osztályt.
        /// </para>
        /// </param>
        public void InvalidateResourceCache(string resourceTable = null, string resourceClass = null)
        {
            //pontos meghatározás, pl. a Strings táblából az összes Login csoportba tartozó en-GB resource
            if (resourceTable != null && resourceClass != null)
            {
                string cacheKey = string.Format(CacheKeyTemplate, CultureDiscriminator, resourceTable, resourceClass);
                HttpRuntime.Cache.Remove(cacheKey);
            }
            //az összes Login csoportba tartozó en-GB resource (ez csak egy controll cache elem, minek a frissdítése kidonja a függőket)
            else if (resourceTable != null)
            {
                string cacheKey = string.Format(TableLevelCacheKeyTemplate, CultureDiscriminator, resourceTable);
                HttpRuntime.Cache.Insert(cacheKey, DateTime.Now);
            }
            else //az összes en-GB resource (ez csak egy controll cache elem, minek a frissdítése kidonja a függőket)
            {
                string cacheKey = string.Format(CultureLevelCacheKeyTemplate, CultureDiscriminator);
                HttpRuntime.Cache.Insert(cacheKey, DateTime.Now);
            }
        }


        /// <summary>
        /// Megszerzi adatbázisból (cache-en keresztül) egy resource csoport összes elemét
        /// </summary>
        /// <param name="resourceTable"></param>
        /// <param name="resourceClass"></param>
        /// <param name="fromCache">ha itt true-t ad vissza, az azt jelenti hogy a cache-ből adta vissza és nem ment a repositoryhoz</param>
        /// <param name="reload">Ha true, akkor tuti elmegy a repositoryba érte, hogy frissítse</param>
        /// <returns></returns>
        private StringDictionary GetDictionary(string resourceTable, string resourceClass, out bool fromCache, bool reload = false)
        {
            StringDictionary dictionary;
            string resourceCacheKey = string.Format(CacheKeyTemplate, CultureDiscriminator, resourceTable, resourceClass);
            string tableCacheKey = string.Format(TableLevelCacheKeyTemplate, CultureDiscriminator, resourceTable);
            string cultureCacheKey = string.Format(CultureLevelCacheKeyTemplate, CultureDiscriminator);

            if (HttpRuntime.Cache[tableCacheKey] == null)
                HttpRuntime.Cache.Insert(tableCacheKey, DateTime.Now);
            if (HttpRuntime.Cache[cultureCacheKey] == null)
                HttpRuntime.Cache.Insert(cultureCacheKey, DateTime.Now);

            dictionary = (StringDictionary)HttpRuntime.Cache[resourceCacheKey];
            fromCache = dictionary != null;
            if (!fromCache || reload)
            {
                dictionary = this.ReadResourceClass(resourceTable, resourceClass, CultureDiscriminator);

                var cacheTimeout = 60;
                if (CacheTimeoutFunction != null)
                    cacheTimeout = CacheTimeoutFunction(resourceTable, resourceClass);

                if (cacheTimeout > 0)
                    HttpRuntime.Cache.Insert(resourceCacheKey, dictionary, new CacheDependency(null, new string[] { tableCacheKey, cultureCacheKey }), System.Web.Caching.Cache.NoAbsoluteExpiration, TimeSpan.FromSeconds(cacheTimeout));
            }

            return dictionary;
        }

        public string GetResourceString(string resourceTable, string resourceClass, string resourceKey, string defaultValue = null, string comment = null, bool isHtml = false)
        {
            bool fromCache;
            var dict = GetDictionary(resourceTable, resourceClass, out fromCache);
            string resString = null;

            if (dict.ContainsKey(resourceKey))
            {
                resString = dict[resourceKey];
            }
            else
            {
                if (fromCache) //nem találta ugyan, de cacheből nézte, most lenyúl érte a repositoryba
                {
                    dict = GetDictionary(resourceTable, resourceClass, out fromCache, reload: true);
                    if (dict.ContainsKey(resourceKey))
                    {
                        resString = dict[resourceKey];
                    }
                }

                if (resString == null && defaultValue != null) //még mindig nincs meg, de van default értékünk
                {
                    resString = defaultValue;
                    try
                    {
                        this.Write(resourceTable, resourceClass, resourceKey, defaultValue, CultureDiscriminator);
                        dict[resourceKey] = defaultValue;
                    }
                    catch { }
                }
            }

            resString = resString ?? resourceKey + "?";

            //TODO: inpage edit trick
            return resString;
        }

        //ez csak update-re legyen képes!
        public void UpdateResourceString(string resourceTable, string resourceClass, string resourceKey, string resourceValue)
        {
            bool fromCache;
            var dict = GetDictionary(resourceTable, resourceClass, out fromCache);
            string resString = null;

            //először meg kell szerezni, bizonyításképpen hogy létezik, mert ez csak Update lehet
            if (dict.ContainsKey(resourceKey))
            {
                resString = dict[resourceKey];
            }
            else //nincs meg
            {
                if (fromCache) //nem találta ugyan, de cacheből nézte, most lenyúl érte a repositoryba
                {
                    dict = GetDictionary(resourceTable, resourceClass, out fromCache, reload: true);
                    if (dict.ContainsKey(resourceKey))
                    {
                        resString = dict[resourceKey];
                    }
                }
            }

            if (resString != null) //megvan, lehet updatelni
            {
                this.Write(resourceTable, resourceClass, resourceKey, resourceValue, CultureDiscriminator);
                dict[resourceKey] = resourceValue;
            }

        }

    }

    public interface IStringResource { }

    [AttributeUsage(AttributeTargets.Method | AttributeTargets.Property, Inherited = false, AllowMultiple = false)]
    sealed class ResourceInfoAttribute : Attribute
    {
        readonly string defaultText;
        readonly string comment;

        public ResourceInfoAttribute(string defaultText, string comment)
        {
            this.defaultText = defaultText;
            this.comment = comment;
        }

        public string DefaultText
        {
            get { return defaultText; }
        }

        public string Comment
        {
            get { return comment; }
        }
    }

}