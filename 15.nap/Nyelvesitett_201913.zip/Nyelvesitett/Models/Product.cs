﻿using Resources;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Nyelvesitett.Models
{
    public enum ProbaEnum
    {
        Alma,
        Barack,
        Citrom,
        Extra
    }


    public class Product
    {
        [HiddenInput(DisplayValue=false)]
        public int Id { get; set; }

        [Display(Name="ItemCode", ResourceType=typeof(Szovegeim))]
        public string ItemCode { get; set; }

        [Display(Name = "Name", ResourceType = typeof(Szovegeim))]
        public string Name { get; set; }
    }
}