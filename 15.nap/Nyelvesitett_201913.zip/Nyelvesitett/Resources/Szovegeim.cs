﻿ 
using System.Web.Configuration;
using System.Collections.Generic;
using System;
using System.Reflection;
using Tocsi.Web.Mvc.Resources;

namespace Resources
{
	public partial class Szovegeim:IStringResource
	{
	
		static DatabaseResourceRepository resourceReader = new DatabaseResourceRepository();

		/// <summary>
		/// Kitörli a memóriából az adatokat, hogy legközelebbi eléréskor újra frissen olvassa be
		/// </summary>
		public static void Reset()
		{
			resourceReader.InvalidateResourceCache("Resources.Strings", "Szovegeim");
		}

		/// <summary>
		/// Szöveges resource enum neve alapján
		/// </summary>
		/// <param name="key">
		/// Az enum érték aminek a nevével megegyező nevű resourcet keressük (nem case sensitive)
		/// </param>
		public static string GetForEnum(Enum key)
		{
			string val;
			try
			{
				PropertyInfo prop = typeof(Resources.Szovegeim).GetProperty(key.ToString(), System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Static | BindingFlags.IgnoreCase | BindingFlags.FlattenHierarchy);
				val = (string)prop.GetValue(null, null);
			}
			catch
			{
				val = resourceReader.GetResourceString("Resources.Strings", "Szovegeim", key.ToString());
			}
			return val;
		}

		///<summary>
		/// <para>Elso extra probalkozas </para>
		///</summary>
		///<param name="masik">
		///<para> a masik parameter </para>
		///</param>
		///<param name="parameter">
		///<para> a tuti kis parameter</para>
		///</param>
		[ResourceInfo(@"#masik Ez az <i>extra</i> resxben #parameter ",@"Elso extra probalkozas #masik a masik parameter #parameter a tuti kis parameter")]
		public static System.Web.Mvc.MvcHtmlString Extra(object masik, object parameter)
		{
			var result = resourceReader.GetResourceString("Resources.Strings", "Szovegeim", "Extra", @"#masik Ez az <i>extra</i> resxben #parameter " , @"Elso extra probalkozas #masik a masik parameter #parameter a tuti kis parameter", true ); 
			result = result.Replace("#masik", string.Format("{0}",masik));
			result = result.Replace("#parameter", string.Format("{0}",parameter));
			return new System.Web.Mvc.MvcHtmlString(result);
		}

		[ResourceInfo(@"Termék kód:",null)]
		public static string ItemCode
		{
			get 
			{ 
				var result = resourceReader.GetResourceString("Resources.Strings", "Szovegeim", "ItemCode", @"Termék kód:" , null, false); 
				return  result;  
			}
		}

		[ResourceInfo(@"Termék neve:",null)]
		public static string Name
		{
			get 
			{ 
				var result = resourceReader.GetResourceString("Resources.Strings", "Szovegeim", "Name", @"Termék neve:" , null, false); 
				return  result;  
			}
		}

		///<summary>
		/// <para>A pelda a parameter</para>
		///</summary>
		[ResourceInfo(@"Ez egy #pelda oldal",@"A pelda a parameter")]
		public static string Title
		{
			get 
			{ 
				var result = resourceReader.GetResourceString("Resources.Strings", "Szovegeim", "Title", @"Ez egy #pelda oldal" , @"A pelda a parameter", false); 
				return  result;  
			}
		}

	}
}

