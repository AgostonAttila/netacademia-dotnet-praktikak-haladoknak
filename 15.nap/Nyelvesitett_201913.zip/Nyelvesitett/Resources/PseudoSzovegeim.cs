﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web;
using Tocsi.Web.Mvc.Resources;

namespace Resources
{
    public class PseudoSzovegeim
    {
        static IResourceRepository resourceReader = new DatabaseResourceRepository();

        /// <summary>
        /// Kitörli a memóriából az adatokat, hogy legközelebbi eléréskor újra frissen olvassa be
        /// </summary>
        public static void Reset()
        {
            resourceReader.InvalidateResourceCache("Resources.Strings", "PseudoSzovegeim");
        }

        public static string Extra
        {
            get
            {
                var result = resourceReader.GetResourceString("Resources.Strings", "PseudoSzovegeim", "Extra", @"Ez már <i>auto</i> és <i>Resourcelike</i>", @"Próba resource", false);
                return result;
            }
        }

        public static System.Web.Mvc.MvcHtmlString ExtraHtml
        {
            get
            {
                var result = resourceReader.GetResourceString("Resources.Strings", "PseudoSzovegeim", "ExtraHtml", @"Ez már <i>auto</i> és <i>Resourcelike</i> meg html is", @"Próba resource", false);
                return new System.Web.Mvc.MvcHtmlString(result);
            }
        }


        public static System.Web.Mvc.MvcHtmlString ExtraHtmlParam(object parameter, object masik)
        {
                var result = resourceReader.GetResourceString("Resources.Strings", "PseudoSzovegeim", "ExtraHtmlParam", @"Ez már <i>auto</i> és <i>Resourcelike</i> meg html is #parameter", @"Próba resource", false);
                result = result.Replace("#parameter", string.Format("{0}", parameter));
                result = result.Replace("#masik", string.Format("{0}", masik));

                return new System.Web.Mvc.MvcHtmlString(result);
        }


        /// <summary>
        /// Szöveges resource enum neve alapján
        /// </summary>
        /// <param name="key">
        /// Az enum érték aminek a nevével megegyező nevű resourcet keressük (nem case sensitive)
        /// </param>
        public static string GetForEnum(Enum key)
        {
            string val;
            try
            {
                PropertyInfo prop = typeof(Resources.PseudoSzovegeim).GetProperty(key.ToString(), System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Static | BindingFlags.IgnoreCase | BindingFlags.FlattenHierarchy);
                val = (string)prop.GetValue(null, null);
            }
            catch
            {
                val = resourceReader.GetResourceString("Resources.Strings", "PseudoSzovegeim", key.ToString());
            }
            return val;
        }



    }
}