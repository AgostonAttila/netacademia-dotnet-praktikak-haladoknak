﻿using Nyelvesitett.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Tocsi.Web.Mvc.Resources;

namespace Nyelvesitett.Controllers
{

    
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult Index()
        {
            ViewBag.Extra = Resources.Szovegeim.Extra(15,"tuti");

   

            var model = new Product
            {
                ItemCode="A-001",
                Name = "Alma"
            };

            return View(model);
        }


        //public string Setup()
        //{
        //    IResourceRepository repos = new DatabaseResourceRepository();
        //    repos.Write("Resources.Strings", "Szovegeim", "Extra", "Ezt mar <i> futasidoben irtam</i>", "HU");

        //    return "ok";
        //}

    }
}
