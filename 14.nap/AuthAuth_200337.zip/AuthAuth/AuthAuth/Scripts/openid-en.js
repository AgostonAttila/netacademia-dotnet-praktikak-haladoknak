/*
	Simple OpenID Plugin
	http://code.google.com/p/openid-selector/
	
	This code is licensed under the New BSD License.
*/

var providers_large = {
	google : {
		name : 'Google',
		url : 'google'
	},
	yahoo : {
		name : 'Yahoo',
		url : 'yahoo'
	},
	facebook: {
	    name: 'Facebook',
	    url: 'facebook'
	},
	stackexchange: {
	    name: 'Stack Overflow',
	    url: 'stackexchange'
	},

	myopenid : {
		name : 'MyOpenID',
		label : 'Enter your MyOpenID username.',
		url: 'MyOpenID;{username}'
	}
};

var providers_small = {
	
};

openid.locale = 'en';
openid.sprite = 'en'; // reused in german& japan localization
openid.demo_text = 'In client demo mode. Normally would have submitted OpenID:';
openid.signin_text = 'Sign-In';
openid.image_title = 'log in with {provider}';
openid.no_sprite = true;
openid.img_path = '/Content/openid/images/';