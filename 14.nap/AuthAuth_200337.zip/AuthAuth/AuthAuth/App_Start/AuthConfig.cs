﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Web.WebPages.OAuth;
using AuthAuth.Models;

namespace AuthAuth
{
    public static class AuthConfig
    {
        public static void RegisterAuth()
        {
            // To let users of this site log in using their accounts from other sites such as Microsoft, Facebook, and Twitter,
            // you must update this site. For more information visit http://go.microsoft.com/fwlink/?LinkID=252166

            //OAuthWebSecurity.RegisterMicrosoftClient(
            //    clientId: "",
            //    clientSecret: "");

            //OAuthWebSecurity.RegisterTwitterClient(
            //    consumerKey: "",
            //    consumerSecret: "");

            OAuthWebSecurity.RegisterFacebookClient(
                appId: "316986198422694",
                appSecret: "e6078c0acacdbe24b08cc4e7ad59ae3f");

            //OAuthWebSecurity.RegisterGoogleClient();
            OAuthWebSecurity.RegisterYahooClient();

            OAuthWebSecurity.RegisterClient(new SajatGoogleKliens(),"Saját Google", null);
            OAuthWebSecurity.RegisterClient(new StackExchangeKliens(), "Stack Overflow", null);
            OAuthWebSecurity.RegisterClient(new VariableUrlOpenIdKliens("MyOpenID","https://__username__.myopenid.com/"), "My OpenID", null);

        }
    }
}
