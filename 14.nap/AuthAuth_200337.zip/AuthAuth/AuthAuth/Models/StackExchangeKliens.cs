﻿using DotNetOpenAuth.AspNet.Clients;
using DotNetOpenAuth.OpenId.Extensions.AttributeExchange;
using DotNetOpenAuth.OpenId.RelyingParty;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AuthAuth.Models
{
    public class StackExchangeKliens:OpenIdClient
    {
        public StackExchangeKliens()
            : base("stackexchange", "https://openid.stackexchange.com/")
        {
        }

        protected override void OnBeforeSendingAuthenticationRequest(IAuthenticationRequest request)
        {
            var fRequest = new FetchRequest();
            fRequest.Attributes.AddRequired(WellKnownAttributes.Contact.Email);
            fRequest.Attributes.AddRequired(WellKnownAttributes.Name.FullName);

            request.AddExtension(fRequest);
        }

        protected override Dictionary<string, string> GetExtraData(IAuthenticationResponse response)
        {
            FetchResponse fResponse = response.GetExtension<FetchResponse>();
            if (fResponse != null)
            {
                var extraData = new Dictionary<string, string>();
                extraData.Add("email", fResponse.GetAttributeValue(WellKnownAttributes.Contact.Email));
                extraData.Add("name", fResponse.GetAttributeValue(WellKnownAttributes.Name.FullName));
                return extraData;
            }
            return null;
        }
    }
}