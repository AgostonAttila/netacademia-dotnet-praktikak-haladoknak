﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Xml.Linq;
using DotNetOpenAuth.OpenId;
using DotNetOpenAuth.OpenId.Extensions.AttributeExchange;
using DotNetOpenAuth.OpenId.RelyingParty;
using DotNetOpenAuth.AspNet.Clients;

namespace AuthAuth.Models
{
    public class VariableUrlOpenIdKliens:OpenIdClient
    {
        public VariableUrlOpenIdKliens(string providerName, Identifier providerIdentifier)
            : base(providerName,  providerIdentifier)
        {
            this.providerIdentifier = providerIdentifier;
        }

        protected static readonly OpenIdRelyingParty RelyingParty = new OpenIdRelyingParty(applicationStore: null);
 
        protected readonly Identifier providerIdentifier;

        protected Identifier ProviderIdentifier
        {
            get
            {
                var cIdent = string.IsNullOrWhiteSpace(UserName) ?
                    this.providerIdentifier :
                    Identifier.Parse(HttpUtility.UrlDecode(this.providerIdentifier).Replace("__username__", this.UserName));

                return cIdent;
            }
        }

        public string UserName { get; set; }

        public override void RequestAuthentication(HttpContextBase context, Uri returnUrl)
        {
            var realm = new Realm(returnUrl.GetComponents(UriComponents.SchemeAndServer, UriFormat.Unescaped));
            IAuthenticationRequest request = RelyingParty.CreateRequest(ProviderIdentifier, realm, returnUrl);

            this.OnBeforeSendingAuthenticationRequest(request);
            request.RedirectToProvider();

        }

        protected override void OnBeforeSendingAuthenticationRequest(IAuthenticationRequest request)
        {
            var fRequest = new FetchRequest();
            fRequest.Attributes.AddRequired(WellKnownAttributes.Contact.Email);
            fRequest.Attributes.AddRequired(WellKnownAttributes.Contact.HomeAddress.City);
            fRequest.Attributes.AddRequired(WellKnownAttributes.Name.First);
            fRequest.Attributes.AddRequired(WellKnownAttributes.Name.Last);

            request.AddExtension(fRequest);
        }
        protected override Dictionary<string, string> GetExtraData(IAuthenticationResponse response)
        {
            FetchResponse fResponse = response.GetExtension<FetchResponse>();
            if (fResponse != null)
            {
                var extraData = new Dictionary<string, string>();
                extraData.Add("email", fResponse.GetAttributeValue(WellKnownAttributes.Contact.Email));
                extraData.Add("country", fResponse.GetAttributeValue(WellKnownAttributes.Contact.HomeAddress.City));
                extraData.Add("firstName", fResponse.GetAttributeValue(WellKnownAttributes.Name.First));
                extraData.Add("lastName", fResponse.GetAttributeValue(WellKnownAttributes.Name.Last));
                return extraData;
            }
            return null;
        }
    }
}