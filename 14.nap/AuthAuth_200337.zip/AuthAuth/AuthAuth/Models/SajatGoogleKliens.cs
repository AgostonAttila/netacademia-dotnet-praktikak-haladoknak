﻿using DotNetOpenAuth.AspNet.Clients;
using DotNetOpenAuth.OpenId.Extensions.AttributeExchange;
using DotNetOpenAuth.OpenId.RelyingParty;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AuthAuth.Models
{
    public class SajatGoogleKliens:OpenIdClient
    {
        public SajatGoogleKliens():base("google",WellKnownProviders.Google)
        {
        
        }

        protected override void OnBeforeSendingAuthenticationRequest(IAuthenticationRequest request)
        {
            var fRequest = new FetchRequest();
            fRequest.Attributes.AddRequired(WellKnownAttributes.Contact.Email);
            fRequest.Attributes.AddRequired(WellKnownAttributes.Contact.HomeAddress.City);
            fRequest.Attributes.AddRequired(WellKnownAttributes.Name.First);
            fRequest.Attributes.AddRequired(WellKnownAttributes.Name.Last);

            request.AddExtension(fRequest);
        }


        protected override Dictionary<string, string> GetExtraData(IAuthenticationResponse response)
        {
            FetchResponse fResponse = response.GetExtension<FetchResponse>();
            if (fResponse != null)
            {
                var extraData = new Dictionary<string, string>();
                extraData.Add("email", fResponse.GetAttributeValue(WellKnownAttributes.Contact.Email));
                extraData.Add("country", fResponse.GetAttributeValue(WellKnownAttributes.Contact.HomeAddress.City));
                extraData.Add("firstName", fResponse.GetAttributeValue(WellKnownAttributes.Name.First));
                extraData.Add("lastName", fResponse.GetAttributeValue(WellKnownAttributes.Name.Last));
                return extraData;
            }
            return null;
        }
    }
}