﻿using MvcApplication10.Mailers;
using MvcApplication10.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Hosting;
using System.Web.Mvc;

namespace MvcApplication10.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            IRegistrationMails mailer = new RegistrationMails();
            var message = mailer.Welcome("Lajos");
            message.Send();

            MailTemplateViewModel model = new MailTemplateViewModel();
            model.Parameterek = new string[] { "Nev", "Cim", "Satobbi"};

            var file = HostingEnvironment.VirtualPathProvider.GetFile("/Views/RegistrationMails/Welcome.cshtml");
            using (var bodyStream = file.Open())
            {
                using (var reader = new StreamReader(bodyStream))
                {
                    model.duma = reader.ReadToEnd();
                }
            }

            model.duma = model.duma.Replace(@"@Html.DisplayFor(m=>ViewData[""Nev""])", "#Nev");

            return View(model);
        }

        [HttpPost]
        public ActionResult Index(MailTemplateViewModel model)
        {
            model.duma = model.duma.Replace("#Nev", @"@Html.DisplayFor(m=>ViewData[""Nev""])");

            DatabaseFileRepository repos = new DatabaseFileRepository();
            repos.SetFile("~/Views/RegistrationMails/Welcome.cshtml", model.duma);

            return RedirectToAction("Index");
        }
    }
}
