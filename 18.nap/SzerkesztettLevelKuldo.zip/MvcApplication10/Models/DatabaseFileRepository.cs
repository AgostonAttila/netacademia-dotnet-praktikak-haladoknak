﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Web;
using Tocsi.Web.VirtualPathProviders;

namespace MvcApplication10.Models
{
    public class DatabaseFileRepository:IFileRepository, IDisposable
    {
        private FileDc dc = new FileDc();

        public bool IsFileExists(string virtualPath)
        {
            bool isExists;

            using (var dc = new FileDc())
            {
                virtualPath = VirtualPathUtility.ToAppRelative(virtualPath);
                isExists = dc.MailTemplates.Any(f => f.Path == virtualPath && f.Domain == "HU");
            }

            return isExists;
        }

        public IFileEntry GetFile(string filepath)
        {
            MailTemplateFile file;

            using (var dc = new FileDc())
            {
                filepath = VirtualPathUtility.ToAppRelative(filepath);
                file = dc.MailTemplates.SingleOrDefault(f => f.Path == filepath && f.Domain == "HU");
            }

            return file;
        }

        public void Dispose()
        {
            dc.Dispose();
        }

        public void SetFile(string templatePath, string body)
        {
            using (var dc = new FileDc())
            {
                var channel = "HU";
                var template = dc.MailTemplates.SingleOrDefault(b => b.Path == templatePath && b.Domain == channel);

                if (template == null)
                {
                    template = new MailTemplateFile { Path = templatePath, Domain = channel };
                    dc.MailTemplates.Add(template);
                }

                template.Contents = body.ToSignedUtf8Bytes();

                dc.SaveChanges();
            }
        }


        public IEnumerable<string> GetFilesInDirectory(string directoryPath)
        {
            IEnumerable<string> files;

            using (var dc = new FileDc())
            {
                directoryPath = VirtualPathUtility.AppendTrailingSlash(VirtualPathUtility.ToAppRelative(directoryPath));

                files = (from f in dc.MailTemplates
                         where f.Path.StartsWith(directoryPath) && f.Domain == "HU"
                         select f.Path).ToList();
            }
            return files;
        }
    }


    public static class StringHelpers
    {
        public static byte[] ToSignedUtf8Bytes(this string text)
        {
            byte[] filebytes = Encoding.UTF8.GetBytes(text);
            byte[] utfbytes = new byte[filebytes.Length + 3];
            utfbytes[0] = 0xEF;
            utfbytes[1] = 0xBB;
            utfbytes[2] = 0xBF;
            filebytes.CopyTo(utfbytes, 3);

            return utfbytes;
        }
    }


    public class MailTemplateFile : IFileEntry
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(255)]
        public string Path { get; set; }

        [Key]
        [Column(Order = 1)]
        public string Domain { get; set; }

        public byte[] Contents { get; set; }
    }

    public class FileDc : DbContext
    {
        public DbSet<MailTemplateFile> MailTemplates { get; set; }
    }

}