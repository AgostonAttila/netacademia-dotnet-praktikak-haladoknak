﻿/// <reference path="../../ckeditor.js" />


CKEDITOR.plugins.add('pholders',
    {
        init: function (editor)
        {


            var dialogContents = "nincs mit betenni";

            if ($('#valtozokpanel').length > 0)
            {
                dialogContents = $('#valtozokpanel').html();

                $('#valtozokpanel').remove();
            }

            editor.addCommand('insertPlaceholder', new CKEDITOR.dialogCommand('pholdersDialog'));

            editor.ui.addButton('Pholders',
            {
                label: 'változó beszúrása',
                command: 'insertPlaceholder',
                icon: this.path + 'images/pholders.png'
            });

            CKEDITOR.dialog.add('pholdersDialog', function (editor) {
                return {
                    title: 'Változók listája',
                    minWidth: 150,
                    minHeight: 200,
                    buttons: [CKEDITOR.dialog.cancelButton],
                    contents:
                          [
                                 {
                                     id: 'tab1',
                                     label: 'Placeholders',
                                     elements:
                                       [
                                      {
                                          type: 'html',
                                          id: 'placeholders',
                                          html: dialogContents
                                      }
                                       ]
                                 }
                          ]
                };
            });


            if (editor.contextMenu)
            {
                editor.addMenuGroup('myGroup');

                editor.addMenuItem('pholderItem',
                               {
                                   label: 'Változó beszúrása',
                                   icon: this.path + 'images/pholders.png',
                                   command: 'insertPlaceholder',
                                   group: 'myGroup'
                               });

                editor.contextMenu.addListener(function (element) {
                    return { pholderItem: CKEDITOR.TRISTATE_OFF };
                });
            }



        }
    }
    );
