using Mvc.Mailer;

namespace MvcApplication10.Mailers
{ 
    public class RegistrationMails : MailerBase, IRegistrationMails 	
	{
		public RegistrationMails()
		{
			MasterName="_Layout";
		}
		
		public virtual MvcMailMessage Welcome(string neve)
		{
			//ViewBag.Data = someObject;
            ViewBag.Nev = neve;

			return Populate(x =>
			{
				x.Subject = "Welcome";
				x.ViewName = "Welcome";
				x.To.Add("some-email@example.com");
			});
		}
 
		public virtual MvcMailMessage ResetPass()
		{
			//ViewBag.Data = someObject;
			return Populate(x =>
			{
				x.Subject = "ResetPass";
				x.ViewName = "ResetPass";
				x.To.Add("some-email@example.com");
			});
		}
 	}
}