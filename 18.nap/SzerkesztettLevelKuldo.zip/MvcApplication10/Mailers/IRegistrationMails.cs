using Mvc.Mailer;

namespace MvcApplication10.Mailers
{ 
    public interface IRegistrationMails
    {
        MvcMailMessage Welcome(string neve);
			MvcMailMessage ResetPass();
	}
}