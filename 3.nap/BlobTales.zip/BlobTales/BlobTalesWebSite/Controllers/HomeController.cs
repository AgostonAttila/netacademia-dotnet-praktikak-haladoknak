﻿using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.ServiceRuntime;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.Mvc;

namespace BlobTalesWebSite.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            var container = GetContainer();
            var model = container.ListBlobs().ToList();

            return View(model);
        }

        private static Microsoft.WindowsAzure.Storage.Blob.CloudBlobContainer GetContainer(string containerName = "pictures")
        {
            string connectionString;

            if (RoleEnvironment.IsAvailable)
                connectionString = CloudConfigurationManager.GetSetting("BlobConnection");
            else
                connectionString = WebConfigurationManager.AppSettings["BlobConnection"];

            var account = CloudStorageAccount.Parse(connectionString);
            var blobClient = account.CreateCloudBlobClient();
            var container = blobClient.GetContainerReference(containerName);
            return container;
        }

        [HttpPost]
        public ActionResult Index(HttpPostedFileBase feltoltendo)
        {
            if (feltoltendo != null && feltoltendo.ContentLength > 0)
            {
                var container = GetContainer();
                var filename = System.IO.Path.GetFileName(feltoltendo.FileName);

                var myBlob = container.GetBlockBlobReference(filename);

                myBlob.UploadFromStream(feltoltendo.InputStream);

                myBlob.Properties.ContentType = feltoltendo.ContentType;
                myBlob.SetProperties();
            }
            return RedirectToAction("Index");
        }



        public ActionResult SAS(string filename)
        {
            string sas = "nincs";

            if (!string.IsNullOrWhiteSpace(filename))
            {
                var container = GetContainer();
                var myBlob = container.GetBlockBlobReference(filename);
                var pol = new SharedAccessBlobPolicy();
                pol.Permissions = SharedAccessBlobPermissions.Read | SharedAccessBlobPermissions.Write;
                pol.SharedAccessExpiryTime = DateTime.Now.AddMinutes(155);
                
                sas = myBlob.GetSharedAccessSignature(pol);
            }
            return View((object)sas);
        }

        public ActionResult GetKeyFor(string path, long size)
        {
            string sas = "nincs";



            if (!string.IsNullOrWhiteSpace(path))
            {
                var pathDarabok = path.Split('/').ToList();
                var container = GetContainer(pathDarabok[0]);
                pathDarabok.RemoveAt(0);
                var folderpath = string.Join("/", pathDarabok);
                var myBlob = container.GetBlockBlobReference(folderpath);
                var pol = new SharedAccessBlobPolicy();
                pol.Permissions = SharedAccessBlobPermissions.Read | SharedAccessBlobPermissions.Write;
                pol.SharedAccessExpiryTime = DateTime.Now.AddMinutes(155);

                sas = "devstoreaccount1/" +path + myBlob.GetSharedAccessSignature(pol);
            }
            return Content(sas);
        }

        [HttpPost]
        [ActionName("GetKeyFor")]
        public void GetKeyForKetto(string path, long size)
        {

        }
    }
}
