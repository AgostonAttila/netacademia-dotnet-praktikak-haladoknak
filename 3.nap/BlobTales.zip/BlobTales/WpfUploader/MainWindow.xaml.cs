﻿using Microsoft.Win32;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Auth;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfUploader
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void browse(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            if (dlg.ShowDialog() == true)
            {
                filePathTextBox.Text = dlg.FileName;
            }
        }

        private void upload(object sender, RoutedEventArgs e)
        {
            var credenc = new StorageCredentials(sasTextBox.Text);
            var blobUri = new Uri("http://127.0.0.1:10000/devstoreaccount1/");
            var account = new CloudStorageAccount(credenc, blobUri, null, null);

            var blobClient = account.CreateCloudBlobClient();
            var container = blobClient.GetContainerReference("pictures");

            var filename = System.IO.Path.GetFileName(filePathTextBox.Text);
            var myBlob = container.GetBlockBlobReference(filename);

            var stream = System.IO.File.OpenRead(filePathTextBox.Text);

            myBlob.BeginUploadFromStream(
                stream, 
                (IAsyncResult result) =>
                {
                    stream.Close();
                    myBlob.EndUploadFromStream(result);
                }, 
                null);

        }
    }
}
