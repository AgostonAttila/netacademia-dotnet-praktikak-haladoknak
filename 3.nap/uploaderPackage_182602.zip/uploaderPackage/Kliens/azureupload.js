﻿azureupload = {

    keyServiceUrl: "",

    uploaded: null,

    receiveMessage: function (event) {
        //ez security lehet hogy csak bizonyos url-től fogadjon el üzenetet. az url-t a parent ablak domainjére kell kicserélni
        //if (event.origin !== "http://vidibit.blob.core.windows.net") return;
        try {
            var message = JSON.parse(event.data);
            switch (message.id) {
                case "getKey": //{id: "getKey", path: "relpath/filename", filename: "filename.jpg", filesize: "4568795"}

                    //itt kell a path-re ajaxszal azure blob SAS-t kérni 
                    var caller = event.source;
                    var callerorigin = event.origin;

                    $.get(azureupload.keyServiceUrl,
                    { "path": message.path, "size": message.filesize },
                    function (result, status) {
                        caller.postMessage('{"id": "key", "key": "' + result + '","filename":"' + message.filename + '" }', callerorigin);
                    },
                    "text");

                    break;
                case "resize": //{id: "resize", height: "66", path: "uploadpath - ahogy a data-azure-upload attribútumban meg lett adva"}
                    //ez csak átméretezi az iframe-et hogy ne látszódjon hogy iframe
                    $("[data-azure-upload='" + message.path + "']").height(message.height);
                    break;
                case "uploaded": //{id: "uploaded", path: "relpath/filename", filename: "filename.jpg"}
                    //itt lehet ajaxszal visszaszólni a szervernek ha adminisztrálni szeretnéd a feltöltött fájlt
                    $.post(azureupload.keyServiceUrl,
                    { "path": message.path, "size": message.filesize },
                    function () {
                        if (azureupload.uploaded) {
                            azureupload.uploaded(message.filename);
                        }
                    });

                    break;
                default:
            }
        }
        catch (e) {
        }
    },

    init: function (serverurl, keyserviceurl) {
        ///<summary>
        ///Ezt kell meghívni page loadban. Az oldalon megkeresi az iframe elemeket akiknek van data-azure-upload attribútuma
        ///</summary>
        ///<param name="serverurl">A CORS Azure hiánya miatt kell a blob storageba egy szerver oldali html. Ez annak az urlje.</param>
        ///<param name="keyserviceurl">
        ///Azure SAS-t ezzel a webszervízzel lehet kérni a fájlnév birtokában. Erről a fő websitenak kell gondoskodni.
        ///get esetén string path és int size paraméterekre egy stringgel kell válaszolnia ami a SAS
        ///post esetén csak egy string path paramétert kap és nem kell válaszolnia. 
        ///Akkor kapja a postot ha sikerült feltölteni a fájlt.
        ///Így lehet adminisztrálni szerver oldalon</param>

        window.addEventListener("message", azureupload.receiveMessage, false);

        azureupload.keyServiceUrl = keyserviceurl;

        $("iframe[data-azure-upload]").each(
            function () {
                var path = $(this).attr("data-azure-upload");
                path = serverurl + "?" + path;
                this.src = path;
            }
    );
    }
}
