﻿//TODO: a félig feltöltött fájlok lekezelése (not commited)

//erre a blobstorage-ra lesznek feltöltve a fájlok. Ez most az url domain része. Kell hozzá még elérési útvonal is (folderpath)
//alkönyvtárazás van és az uploadFile funkcióban lehet megtalálni
var storageUrl;

//a folderPath az url kérdőjel uténi része. ne tartalmazza se a kezdő se a lezáró / jelet
//Relatív könyvtár útvonal a gyökér konténerhez képest. Ebbe a könyvtárba lesz feltöltve a fájl.
var folderPath = "";

//ekkora darabokban (byte) fogja feltöltögetni a fájlokat max 4000000
var pagesize = 4000000;

//ebben várakoznak a kulcsra a feltöltenő fájlok
var keyQueue = {};

$(document).ready(
function () {

    //az alkönyvtár megállapítása az urlből
    var parampos = document.URL.indexOf("?") + 1;
    if (parampos > 0) {
        folderPath = document.URL.substr(parampos);
    }

    if (typeof (FileReader) == "undefined") {
        $("#supported").remove();
        $("#notsupported").show();
    }
    else {
        $("#notsupported").remove();

        var rootpos = document.URL.indexOf("/", 9);
        storageUrl = document.URL.substr(0, rootpos + 1);

        var dropbox = document.getElementById("filedroptarget");
        dropbox.addEventListener("drop", handledrop, false);

        dropbox.addEventListener('dragenter', dragenter, false);
        dropbox.addEventListener('dragexit', dragexit, false);
        dropbox.addEventListener('dragleave', dragexit, false);
        dropbox.addEventListener('dragover', dragover, false);

        window.addEventListener("message", receiveMessage, false);

        $("#filebrowser").change(function () {
            var files = this.files;
            var count = files.length;

            // Only call the handler if 1 or more files was dropped.
            if (count > 0) {
                handleFiles(files);
            }
        });
    }

    resizeMe();
}
);

function resizeMe() {
    var height = $("#page").height()+2;
    parent.postMessage('{"id": "resize", "height": "' + height + '","path": "' + folderPath + '"}', "*");
}

function requestKey(file) {
    keyQueue[file.name] = file;
    parent.postMessage('{"id": "getKey", "path": "' + folderPath + "/" + file.name + '", "filename": "' + file.name + '", "filesize": "' + file.size + '"}', "*");
}

function confirmUpload(file) {
 var messageObjStr = '{"id": "uploaded", "path": "' + folderPath + "/" + file.name + '", "filename": "' + file.name + '", "filesize": "' + file.size + '"}'; 
 parent.postMessage(messageObjStr, "*");
}

function receiveMessage(event) {
    //ez security lehet hogy csak bizonyos url-től fogadjon el üzenetet. az url-t a parent ablak domainjére kell kicserélni pl. http://www.netacademia.hu
    //if (event.origin !== "http://www.itfactory.hu") return;

    var message = JSON.parse(event.data);
    switch (message.id) {
        case "key": //{id: "key", filename: "filename.jpg", key: "krixkrax"}
            //megjött a kulcs
            //a file objektum visszaszerzése
            var file = keyQueue[message.filename];
            delete keyQueue[message.filename];
            uploadFile(file, message.key);
            break;
        default:
    }
}

/**************************************************************************/

function dragover(evt) {
    evt.stopPropagation();
    evt.preventDefault();
}


function dragenter(evt) {
    evt.stopPropagation();
    evt.preventDefault();
    $("#filedroptarget").addClass('dragenter');
}

function dragexit(evt) {
    evt.stopPropagation();
    evt.preventDefault();
    $("#filedroptarget").removeClass('dragenter');
}

function handledrop(e) {
    e.stopPropagation(); // Stops some browsers from redirecting.
    e.preventDefault();

    $("#filedroptarget").removeClass('dragenter');

    var files = e.dataTransfer.files;
    var count = files.length;
 
    // Only call the handler if 1 or more files was dropped.
    if (count > 0) {
        handleFiles(files);
    }
}



/**************************************************/

function handleFiles(files) {
    for (var i = 0; i < files.length; i++) {
        //uploadFile(files[i], key);
        requestKey(files[i]);
    }
}

//---------------------------------------------------

function uploadFile(file, key) {
    ///<summary>
    ///egy fájlt beolvsa, darabol és a darabokat feltölti szépen sorban egymás után
    ///</summary>
    ///<param name="file">Fájl objektum</param>


    //kirakom a progressbart
    $("#progressContainer").append("<div data-file='" + file.name + "'><div class='progress'></div><span class='title'>" + file.name + "</span> <span class='counter'>0 kB</span></div>");
    resizeMe();

    readFileChunk(file, key); //a rekurzív művelet belökése
}

function readFileChunk(file, key, page) {
    ///<summary>
    ///Beolvas egy darabot a fájlból (async) HTML5 fileAPI (IE9 nem viszi). 
    ///Ha végzett meghívja a feltöltést (async) uploadChunk
    ///</summary>
    ///<param name="file">Fájl objektum</param>
    ///<param name="key">SAS key</param>
    ///<param name="page">hogy hányadik darabot kell feldolgozni</param>
    
   
    if (!page)
        page = 0;

    var maxPages = Math.ceil(file.size / pagesize) - 1;
    //mivel fix blokk mérettel dolgozom ez mindig kiszámolható
    //ha tehát elértük a végét, akkor nem kell beolvasni semmit, hanem helyette commitálni kell a cloudban
    if (page > maxPages || maxPages < 0) {
        var cXml = createCommitXml(maxPages);
        commitFile(cXml, file, key);
        return;
    }
    //console.log(page); //csak debugnak

    var reader = new FileReader();
    
    var blob = file.slice(page * pagesize, page * pagesize + pagesize);
    reader.onloadend = function (evt) {
        if (evt.target.readyState == FileReader.DONE) { // DONE == 2
            //console.log(evt.target.result.byteLength); //csak debugnak
            uploadChunk(evt.target.result, file, key, page);
        }
    };
    reader.readAsArrayBuffer(blob);
}


function uploadChunk(bytes, file, key, page) {
    ///<summary>
    ///feltölt egy beolvasott darabot a fájlból. 
    ///Ha végzett meghívja a file további darabjainak betöltését readFileChunk (rekurzív)
    ///</summary>
    ///<param name="bytes">A fájl beolvasott bytejai</param>
    ///<param name="file">Fájl objektum</param>
    ///<param name="key">SAS key</param>
    ///<param name="page">hogy hányadik darabot kell feldolgozni</param>

    var blockid = $.base64.encode((page+1000).toString());
    var uInt8Array = new Uint8Array(bytes);

    var uploadurl;
    //ha a key nem tartalmaz / jelet :) mert akkor tényleg csak a key jött vissza, egyébként a key-ben a relatív feltöltési url van SASsal együtt, ami most fix helyzet
//    if (key.indexOf("/") < 0) {
//        uploadurl = storageUrl + folderPath + "/" + file.name + '?comp=block&blockid=' + blockid + '&' + key;
//    } else {
        uploadurl = storageUrl + key + '&comp=block&blockid=' + blockid;
//    }

    var xhr = new XMLHttpRequest();
    xhr.open('PUT', uploadurl, true);
    xhr.setRequestHeader('x-ms-blob-type', 'BlockBlob');
    xhr.setRequestHeader('x-ms-date', new Date());
    xhr.setRequestHeader('x-ms-version', '2011-08-18');
    xhr.setRequestHeader('x-ms-blob-content-type', file.type);

    xhr.onload = function () {
        page++;

        var uploaded = pagesize * page;
        var progressPercent = Math.round((uploaded / file.size) * 100);
        if (progressPercent > 100) progressPercent = 100;


        //$("[data-file='" + file.name + "'] .progress").width(progressPercent + "%");

        var parentwidth = $("[data-file='" + file.name + "'] .progress").parent().width();
        var progressWidth = parentwidth * progressPercent / 100.0;
        $("[data-file='" + file.name + "'] .progress").width(progressWidth);
        $("[data-file='" + file.name + "'] .counter").text(Math.round(uploaded/1000.0) + ' kB');

        readFileChunk(file, key, page);
    };

    xhr.onerror = function (jqXhr, textStatus, errorMessage) {
        $("[data-file='" + file.name + "']").remove();
        if (errorMessage === undefined)
            $("#uploadedContainer").append("<div class='failed'>" + file.name + "</div>");
        else
            $("#uploadedContainer").append("<div class='failed'>" + file.name + "<br/>" + errorMessage + "</div>");
        resizeMe();
    }

    xhr.onloadend = function (jqXhr, textStatus, errorMessage) {
        if (this.status == 403) {
            $("[data-file='" + file.name + "']").remove();
            $("#uploadedContainer").append("<div class='failed'>" + file.name + "<br/>Jogosultsági hiba!</div>");
            resizeMe();
        }
    }

    xhr.ontimeout = function (jqXhr, textStatus, errorMessage) {
        $("[data-file='" + file.name + "']").remove();
        $("#uploadedContainer").append("<div class='failed'>" + file.name + "<br/>Időtúllépési hiba</div>");
        resizeMe();
    }

    xhr.upload.onprogress = function (e) {
        if (e.lengthComputable) {
            var uploaded = pagesize * page + e.loaded;

            var progressPercent = Math.round((uploaded / file.size) * 100);
            if (progressPercent > 100) progressPercent = 100;

            //$("[data-file='" + file.name + "'] .progress").width(progressPercent + "%");
            var parentwidth = $("[data-file='" + file.name + "'] .progress").parent().width();
            var progressWidth = parentwidth * progressPercent / 100.0;
            $("[data-file='" + file.name + "'] .progress").width(progressWidth);
            $("[data-file='" + file.name + "'] .counter").text(Math.round(uploaded / 1000.0) + ' kB');
        
        }
    }

    xhr.send(bytes);
}

function commitFile(commitXml, file, key) {
    ///<summary>
    ///Ha a fájl összes darabja fel van töltve, akkor ez szól a blob storagenak, hogy kész, már látszódhat másnak is. 
    ///</summary>
    ///<param name="commitXml">Egy xml amiben a blob blokkok azonosítóinak listája van. 
    ///A createCommitXml funkció állítja össze
    ///Ezek a blokkok ebben a sorrenben alkotják a fájlt.</param>
    ///<param name="file">Fájl objektum</param>
    ///<param name="key">SAS key</param>


    var uploadurl;
    //ha a key nem tartalmaz / jelet :) mert akkor tényleg csak a key jött vissza, egyébként a key-ben a relatív feltöltési url van SASsal együtt, ami most fix helyzet

//    if (key.indexOf("/") < 0) {
//        uploadurl = storageUrl + folderPath + "/" + file.name + '?comp=blocklist&' + key;
//    } else {
        uploadurl = storageUrl + key + '&comp=blocklist';
//    }

    $.ajax(
    {
        type: 'PUT',
        url: uploadurl,
        data: commitXml,
        headers:
            {
                'x-ms-date': new Date(),
                'x-ms-version': '2011-08-18',
                'x-ms-blob-content-type': file.type
            },
        dataType: 'xml',
        success: function () {
            $("[data-file='" + file.name + "']").remove();
            $("#uploadedContainer").append("<div>" + file.name + "</div>");
            resizeMe();
            confirmUpload(file);
        },
        error: function (jqXhr, textStatus, errorMessage) {
            $("[data-file='" + file.name + "']").remove();
            if (errorMessage === undefined)
                $("#uploadedContainer").append("<div class='failed'>" + file.name +  "</div>");
            else
                $("#uploadedContainer").append("<div class='failed'>" + file.name + "<br/>" + errorMessage + "</div>");
            resizeMe();
        }

    });
}


function createCommitXml(lastId) {
    ///<summary>
    ///Annak tudatában hogy hány darabból lett feltöltve a fájl összepakolja az id listáját egy xml-be a commithoz 
    ///</summary>
    ///<param name="lastId">a feltöltött darabok száma-1 (mert a földszinttől számolunk)</param>

    var xml = '<?xml version="1.0" encoding="utf-8"?><BlockList>';
    for (var i = 0; i <= lastId; i++) {
        xml += '<Latest>' + $.base64.encode((i+1000).toString()) +'</Latest>';
    }
    xml += '</BlockList>';

    return xml; 
}

/**************************************************/
