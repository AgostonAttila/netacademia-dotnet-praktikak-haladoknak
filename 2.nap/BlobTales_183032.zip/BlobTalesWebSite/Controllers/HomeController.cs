﻿using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.ServiceRuntime;
using Microsoft.WindowsAzure.Storage;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.Mvc;

namespace BlobTalesWebSite.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            var container = GetContainer();
            var model = container.ListBlobs().ToList();

            return View(model);
        }

        private static Microsoft.WindowsAzure.Storage.Blob.CloudBlobContainer GetContainer()
        {
            string connectionString;

            if (RoleEnvironment.IsAvailable)
                connectionString = CloudConfigurationManager.GetSetting("BlobConnection");
            else
                connectionString = WebConfigurationManager.AppSettings["BlobConnection"];

            var account = CloudStorageAccount.Parse(connectionString);
            var blobClient = account.CreateCloudBlobClient();
            var container = blobClient.GetContainerReference("pictures");
            return container;
        }

        [HttpPost]
        public ActionResult Index(HttpPostedFileBase feltoltendo)
        {
            if (feltoltendo != null && feltoltendo.ContentLength > 0)
            {
                var container = GetContainer();
                var filename = System.IO.Path.GetFileName(feltoltendo.FileName);

                var myBlob = container.GetBlockBlobReference(filename);

                myBlob.UploadFromStream(feltoltendo.InputStream);

                myBlob.Properties.ContentType = feltoltendo.ContentType;
                myBlob.SetProperties();
            }
            return RedirectToAction("Index");
        }
    }
}
