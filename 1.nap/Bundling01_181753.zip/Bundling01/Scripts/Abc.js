﻿alert("Hello Leo adjksgh");

function egy(valtozo)
{
    var masikValtozo = 125;

    masikValtozo = masikValtozo * valtozo;

    return masikValtozo;
}