﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Optimization;

namespace Bundles2.Models
{
    public class MagyarTransform:IBundleTransform
    {
        public void Process(BundleContext context, BundleResponse response)
        {
            response.Content = response.Content.Replace("piros","red");
            //response.ContentType = 
        }
    }
}