﻿using MvcApplication10.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcApplication10.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            var dc = new DC();
            dc.ApplyFilters(new IFilter<DC>[] { new ActiveProducts() });

            var model = dc.Products.ToList();

            return View(model);
        }

    }
}
