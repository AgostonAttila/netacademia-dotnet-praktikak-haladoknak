﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Hosting;

namespace MvcApplication10.Models
{
    public class EnumerablePathProvider:VirtualPathProvider
    {
        IFileRepository repository;

        public EnumerablePathProvider(IFileRepository repository, string virtualRoot, string fileEndingFilter = null)
        {
            this.VirtualRoot = virtualRoot;
            this.FileEndingFilter = fileEndingFilter;
            this.repository = repository;
        }

        public override bool FileExists(string virtualPath)
        {
            if (!IsFileWatched(virtualPath))
                return base.FileExists(virtualPath);

            return virtualPath.EndsWith("Index.cshtml");// repository.IsFileExists(virtualPath);
        }

        public override VirtualFile GetFile(string virtualPath)
        {
            if (!IsFileWatched(virtualPath))
                return base.GetFile(virtualPath);

            return new VirtualMyFile(this, virtualPath);
        }


        public string FileEndingFilter { get; set; }

        private string virtualRoot;
        public string VirtualRoot
        {
            get
            {
                return this.virtualRoot;
            }

            set
            {
                this.virtualRoot = VirtualPathUtility.AppendTrailingSlash(VirtualPathUtility.ToAppRelative(value));
            }
        }

        private bool IsWatchedPath(string virtualPath)
        {
            string checkPath = VirtualPathUtility.ToAppRelative(virtualPath);

            if (checkPath.Length + 1 == VirtualRoot.Length)
                checkPath = VirtualPathUtility.AppendTrailingSlash(checkPath);

            bool retval = checkPath.StartsWith(VirtualRoot, StringComparison.InvariantCultureIgnoreCase);

            return retval;
        }

        private bool IsFileWatched(string virtualPath)
        {
            if (!string.IsNullOrWhiteSpace(FileEndingFilter))
            {
                if (!virtualPath.EndsWith(FileEndingFilter, StringComparison.InvariantCultureIgnoreCase))
                    return false;
            }

            if (IsWatchedPath(virtualPath))
            {
                if (!repository.IsFileExists(virtualPath))
                {
                    //hack a tanfolyamhoz!
                    byte[] filebytes;
                    var path = HttpContext.Current.Server.MapPath("~/Views/Home/Index.cshtml");
                    using (var file = new FileStream(path, FileMode.Open))
                    {
                        filebytes = new byte[file.Length];
                        file.Read(filebytes, 0, filebytes.Length);
                    }

                    repository.WriteFile(virtualPath, filebytes);
                }

                return true;
            }

            return false;
            
        }


        private class VirtualMyFile : VirtualFile
        {
            EnumerablePathProvider gazdi;
            public VirtualMyFile(EnumerablePathProvider gazdi, string virtualPath)
                : base(virtualPath)
            {
                this.gazdi = gazdi;
            }

            public override System.IO.Stream Open()
            {
                System.IO.Stream stream;

                var file = gazdi.repository.GetFile(this.VirtualPath);
                stream = new MemoryStream(file.Contents);

                return stream;
            }
        }

    }
}