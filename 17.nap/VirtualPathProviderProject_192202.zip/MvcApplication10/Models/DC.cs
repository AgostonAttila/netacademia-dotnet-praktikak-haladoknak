﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace MvcApplication10.Models
{
    public class DC:DbContext
    {
        public IDbSet<Product> Products { get; set; }
        public IDbSet<Category> Categories { get; set; }


        public void ApplyFilters(IEnumerable<IFilter<DC>> filters)
        {
            foreach (var item in filters)
            {
                item.DbContext = this;
                item.Apply();
            }
        }
    }


}