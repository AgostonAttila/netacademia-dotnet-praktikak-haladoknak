﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcApplication10.Models
{
    public interface IFileRepository
    {
        bool IsFileExists(string virtualPath);
        IFileEntry GetFile(string virtualPath);

        //hack a tanfolyamhoz!
        void WriteFile(string virtualPath, byte[] contents);
    }

    public interface IFileEntry
    {
        string Path { get; set; }
        byte[] Contents { get; set; }
    }
}