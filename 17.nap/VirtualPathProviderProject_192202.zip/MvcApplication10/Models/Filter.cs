﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace MvcApplication10.Models
{
    public interface IFilter<T> where T : DbContext
    {
        T DbContext { get; set; }
        void Apply();
        
    }

    public class ActiveProducts : IFilter<DC>
    {
        public DC DbContext { get; set; }

        public void Apply()
        {
            DbContext.Products = new FilteredDbSet<Product>(DbContext, d => d.IsActive && (d.Category != null && d.Category.IsActive));
        }
    }
}