﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace MvcApplication10.Models
{
    public class DatabaseFileRepository:IFileRepository, IDisposable
    {
        private FileDc dc = new FileDc();

        public bool IsFileExists(string virtualPath)
        {
            //itt van a culture vagy domain vizsgálat helye is!
            return dc.MyFiles.Any(f => f.Path == virtualPath);
        }

        public IFileEntry GetFile(string virtualPath)
        {
            //itt van a culture vagy domain vizsgálat helye is!
            return dc.MyFiles.AsNoTracking().Single(f => f.Path == virtualPath);
        }

        public void Dispose()
        {
            dc.Dispose();
        }


        public void WriteFile(string virtualPath, byte[] contents)
        {
            MyFile file = new MyFile { Contents = contents, Path = virtualPath };
            dc.MyFiles.Add(file);
            dc.SaveChanges();
        }
    }

    public class MyFile : IFileEntry
    {
        public int Id { get; set; }

        //public string Etc { get; set; }

        [StringLength(256)]
        public string Path
        {
            get;
            set;
        }

        public byte[] Contents
        {
            get;
            set;
        }
    }

    public class FileDc : DbContext
    {
        public DbSet<MyFile> MyFiles { get; set; }
    }

}